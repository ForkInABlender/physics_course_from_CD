    var myCurrentId;
	var firstClick='false';
	
	function closeit()
{
close();
window.parent.close();
}
    function ChangeTRBGcolor(id)
	{
	   	document.getElementById(id).style.backgroundColor="#D6D6D6";

        if(firstClick == 'true')
	    {
			document.getElementById(myCurrentId).style.backgroundColor="#FFFFFF";			
		}

		firstClick='true';
		myCurrentId = id;
	}


